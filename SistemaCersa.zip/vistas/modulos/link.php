

<link rel="stylesheet" type="text/css" href="<?php echo SERVERURL;?>vistas/js/sweetalert/sweetalert2.min.css">
<script type="text/javascript" src="<?php echo SERVERURL;?>vistas/js/sweetalert/sweetalert2.min.js" ></script>
<link rel="stylesheet" href="<?php echo SERVERURL;?>vistas/otros/icofonts-material/css/materialdesignicons.min.css">
<link rel="stylesheet" href="vistas/otros/icofonts-awesome/css/font-awesome.css">

   <link rel="stylesheet" href="<?php echo SERVERURL;?>vistas/css/style.css">
 <!-- <link rel="stylesheet" href="vistas/css/bootstrap-datetimepicker.css">
  <link rel="stylesheet" href="vistas/css/bootstrap-datetimepicker.min.css">-->
  <link rel="stylesheet" href="<?php echo SERVERURL;?>vistas/css/sweetalert2.css">
 <link rel="shortcut icon" href="<?php echo SERVERURL;?>vistas/images/favicon.ico" />
