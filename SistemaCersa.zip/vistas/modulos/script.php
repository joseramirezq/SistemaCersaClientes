
<!--programacion de las altertas-->
<script src="vistas/js/main.js"></script>

<!--alertas-->
	<script src="vistas/js/jquery-3.1.1.min.js"></script>
	<script src="vistas/js/jquery.min.js"></script>
	<script src="vistas/js/sweetalert2.min.js"></script>
	<script src="vistas/js/main.js"></script>
	<script src="vistas/js/material.min.js"></script>

 
<!--jv de laplantilla-->
<script src="vistas/js/vendor.bundle.base.js"></script>
<script src="vistas/js/vendor.bundle.addons.js"></script>

<!--jv de los graficos -->
<script src="vistas/js/off-canvas.js"></script>
<script src="vistas/js/misc.js"></script>
<script src="vistas/js/chart.js"></script>

<!--jv datatable -->
<script src="vistas/js/data-table/lib/data-table/datatables.min.js"></script>
<script src="vistas/js/data-table/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="vistas/js/data-table/lib/data-table/dataTables.buttons.min.js"></script>
<script src="vistas/js/data-table/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="vistas/js/data-table/lib/data-table/jszip.min.js"></script>
<script src="vistas/js/data-table/lib/data-table/vfs_fonts.js"></script>
<script src="vistas/js/data-table/lib/data-table/buttons.html5.min.js"></script>
<script src="vistas/js/data-table/lib/data-table/buttons.print.min.js"></script>
<script src="vistas/js/data-table/lib/data-table/buttons.colVis.min.js"></script>
<script src="vistas/js/data-table/init/datatables-init.js"></script>


