<?php

const SERVER="localhost";
const DB="sistemacersa";
const USER="root";
const PASS="";

//SISTEMA GESTOR DE BASE DE DATOS
const SGBD="mysql:host=".SERVER.";dbname=".DB;


//no modificar
const METHOD="AES-256-CBC";

//modificar si se desea
const SECRET_KEY='$SC@2019';
const SECRET_IV='201926';