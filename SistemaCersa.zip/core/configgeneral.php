<?php
const SERVERURL = "http://localhost/proyectos/SistemaCersa/";
const COMPANY = "SISTEMA CERSA";
date_default_timezone_set("America/Lima");

